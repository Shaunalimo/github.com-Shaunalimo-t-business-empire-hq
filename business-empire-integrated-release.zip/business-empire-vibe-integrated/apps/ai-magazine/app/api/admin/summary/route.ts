import { tenantApiGate } from "../../../../lib/tenant-api";

export async function GET() {
  return tenantApiGate(["staff", "admin"]);
}
