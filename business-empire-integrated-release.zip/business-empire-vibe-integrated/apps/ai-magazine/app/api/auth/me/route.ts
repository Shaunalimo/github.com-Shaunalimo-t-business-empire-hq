import { NextResponse } from "next/server";
import { currentCustomer } from "../../../../lib/identity";
export async function GET() { try { const user = await currentCustomer(); return NextResponse.json(user ? { authenticated: true, user } : { authenticated: false }, { status: user ? 200 : 401, headers: { "Cache-Control": "no-store" } }); } catch { return NextResponse.json({ error: "identity_service_unavailable" }, { status: 503, headers: { "Cache-Control": "no-store" } }); } }
