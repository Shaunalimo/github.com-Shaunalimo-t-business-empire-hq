import { startCustomerMfa } from "../../../../../lib/identity";
export async function POST(req: Request) { return startCustomerMfa(req); }
