import { requestCustomerPasswordReset } from "../../../../../lib/identity";
export async function POST(req: Request) { return requestCustomerPasswordReset(req); }
