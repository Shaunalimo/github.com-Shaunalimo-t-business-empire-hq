import { loginCustomer } from "../../../../lib/identity";
export async function POST(req: Request) { return loginCustomer(req); }
