import { googleCustomerSignIn } from "../../../../lib/identity";
export async function POST(req: Request) { return googleCustomerSignIn(req); }
