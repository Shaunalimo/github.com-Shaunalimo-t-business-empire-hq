import { requestCustomerEmailVerification } from "../../../../../../lib/identity";
export async function POST(req: Request) { return requestCustomerEmailVerification(req); }
