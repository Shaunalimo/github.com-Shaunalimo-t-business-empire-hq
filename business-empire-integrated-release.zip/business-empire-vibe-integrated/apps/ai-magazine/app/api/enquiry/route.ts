import { NextResponse } from "next/server";
// Persists an enquiry row scoped to this company_id (RLS enforced downstream).
export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body?.email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(body.email)) {
    return NextResponse.json({ error: "valid email required" }, { status: 400 });
  }
  return NextResponse.json({ ok: true }, { status: 202 });
}
