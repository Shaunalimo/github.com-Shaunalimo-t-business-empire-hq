'use client';
import Link from "next/link";
import { useEffect, useState } from "react";

type Business = { slug: string; name: string; role: string };
type Project = { id: string; name: string; targetBusinessSlug: string; status: string; updatedAt: string; _count: { files: number } };

export default function ProjectsPage() {
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [businessSlug, setBusinessSlug] = useState("growthboost");
  const [projects, setProjects] = useState<Project[]>([]);
  const [name, setName] = useState("");
  const [prompt, setPrompt] = useState("");
  const [email, setEmail] = useState("");
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function loadProjects(slug: string) {
    const response = await fetch(`/api/projects?business=${encodeURIComponent(slug)}`, { cache: "no-store" });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not load projects.");
    setProjects(data.projects || []);
  }
  useEffect(() => {
    fetch("/api/auth/me", { cache: "no-store" }).then(async response => {
      const data = await response.json();
      if (!response.ok) throw new Error("Please sign in to open your project studio.");
      setEmail(data.user.email); setBusinesses(data.businesses || []);
      const first = data.businesses?.[0]?.slug || "growthboost";
      setBusinessSlug(first); await loadProjects(first);
    }).catch(e => setError(e.message));
  }, []);
  useEffect(() => { if (businesses.some(b => b.slug === businessSlug)) loadProjects(businessSlug).catch(e => setError(e.message)); }, [businessSlug, businesses]);

  async function createProject(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setNotice("");
    try {
      const response = await fetch("/api/projects", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ businessSlug, name, prompt }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error === "free_or_current_plan_project_limit_reached" ? "You have reached the website allowance on your current plan. Paid upgrades are not connected yet." : (data.error || "Project could not be created."));
      setName(""); setPrompt(""); setNotice(data.notice); await loadProjects(businessSlug);
    } catch (e) { setError(e instanceof Error ? e.message : "Project could not be created."); }
    finally { setBusy(false); }
  }
  async function signOut() { await fetch("/api/auth/logout", { method: "POST" }); location.href = "/login"; }

  if (error.includes("Please sign in")) return <main style={wrap}><h1>Project studio</h1><p>{error}</p><Link href="/login">Sign in</Link></main>;
  return <main style={wrap}>
    <header style={header}><div><Link href="/" style={{ color: "#b9a5ff" }}>VIBE / EMPIRE</Link><h1 style={{ marginBottom: 4 }}>Project studio</h1><p style={muted}>{email ? `Signed in as ${email}` : "Loading account…"}</p></div><nav style={{ display: "flex", gap: 14, flexWrap: "wrap" }}><Link href="/marketplace" style={navLink}>Marketplace</Link><Link href="/plans" style={navLink}>Plans</Link><button onClick={signOut} style={quietButton}>Sign out</button></nav></header>
    <section style={panel}>
      <h2 style={{ marginTop: 0 }}>Create a website or app workspace</h2>
      <p style={muted}>Choose one of the businesses you are authorised to access. CEO Headquarters can create group projects for any of the seven businesses.</p>
      <form onSubmit={createProject} style={{ display: "grid", gap: 12 }}>
        <label>Business workspace<select value={businessSlug} onChange={e => setBusinessSlug(e.target.value)} style={field}>{businesses.map(b => <option key={b.slug} value={b.slug}>{b.name} · {b.role}</option>)}</select></label>
        <label>Project name<input required minLength={2} maxLength={80} value={name} onChange={e => setName(e.target.value)} placeholder="e.g. GrowthBoost landing page" style={field} /></label>
        <label>Describe what you want to build<textarea required minLength={12} maxLength={6000} rows={5} value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Describe the website or application, its pages, users, features and style…" style={{ ...field, resize: "vertical" }} /></label>
        <button disabled={busy || businesses.length === 0} style={primaryButton}>{busy ? "Saving workspace…" : "Create project workspace"}</button>
      </form>
      {notice && <p role="status" style={{ color: "#bbf7d0" }}>{notice}</p>}
      {error && <p role="alert" style={{ color: "#fca5a5" }}>{error}</p>}
    </section>
    <section style={{ marginTop: 26 }}><h2>Saved projects</h2>{projects.length === 0 ? <p style={muted}>No projects in this business workspace yet.</p> : <div style={grid}>{projects.map(project => <article key={project.id} style={projectCard}><p style={{ color: "#a78bfa", fontSize: 12, textTransform: "uppercase" }}>{project.targetBusinessSlug.replaceAll("-", " ")}</p><h3>{project.name}</h3><p style={muted}>{project._count.files} starter files · {project.status}</p><Link href={`/projects/${project.id}?business=${project.targetBusinessSlug}`} style={projectLink}>Open workspace →</Link></article>)}</div>}</section>
    <p style={{ ...muted, marginTop: 26 }}>Free plan: 3 website projects. This workspace creates starter files; AI generation requires an AI Gateway key/model. Remote sandbox execution, custom domains and deployment are not connected yet.</p>
  </main>;
}
const wrap: React.CSSProperties = { maxWidth: 1100, margin: "0 auto", padding: "28px 22px 80px" };
const header: React.CSSProperties = { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 20, flexWrap: "wrap", marginBottom: 28 };
const panel: React.CSSProperties = { background: "#121a30", border: "1px solid #26314d", borderRadius: 18, padding: 24 };
const muted: React.CSSProperties = { color: "#aeb9d3", lineHeight: 1.55 };
const navLink: React.CSSProperties = { color: "#c9c0ef", alignSelf: "center" };
const field: React.CSSProperties = { display: "block", width: "100%", boxSizing: "border-box", marginTop: 7, padding: 12, borderRadius: 9, border: "1px solid #35405d", background: "#0b1020", color: "#fff" };
const primaryButton: React.CSSProperties = { border: 0, borderRadius: 10, background: "#8b5cf6", color: "white", padding: 14, fontWeight: 700, cursor: "pointer" };
const quietButton: React.CSSProperties = { border: "1px solid #35405d", borderRadius: 9, background: "transparent", color: "#e5e7eb", padding: "8px 12px" };
const grid: React.CSSProperties = { display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(230px,1fr))", gap: 14 };
const projectCard: React.CSSProperties = { background: "#121a30", border: "1px solid #26314d", borderRadius: 16, padding: 20 };
const projectLink: React.CSSProperties = { color: "#c4b5fd", fontWeight: 700 };
