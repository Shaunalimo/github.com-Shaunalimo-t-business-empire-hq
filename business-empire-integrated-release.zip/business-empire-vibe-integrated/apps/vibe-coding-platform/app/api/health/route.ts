import { NextResponse } from "next/server";
export async function GET() {
  return NextResponse.json({ app: "vibe-coding-platform", status: "source_ready", generation: "not_configured", sandbox: "not_configured", marketplaceCheckout: "not_configured" }, { headers: { "Cache-Control": "no-store" } });
}
