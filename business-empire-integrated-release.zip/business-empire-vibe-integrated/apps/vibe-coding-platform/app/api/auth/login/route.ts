import { NextResponse } from "next/server";
import type { Prisma } from "@empire/db";
import { prisma } from "@empire/db";
import { decryptMfaSecret, newSessionToken, sha256, verifyPassword, verifyTotp } from "@empire/core";
import { VIBE_BUSINESS_TARGETS } from "@empire/core";
import { VIBE_SESSION_COOKIE } from "../../../../lib/auth";
import { NO_STORE, rejectVibeOrigin, vibeRateLimited } from "../../../../lib/security";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const blocked = rejectVibeOrigin(request);
  if (blocked) return blocked;
  const body = await request.json().catch(() => null);
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  const mfaCode = typeof body?.mfaCode === "string" ? body.mfaCode.trim() : "";
  const recoveryCode = typeof body?.recoveryCode === "string" ? body.recoveryCode.trim() : "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254 || !password || password.length > 256) {
    return NextResponse.json({ error: "invalid_credentials" }, { status: 401, headers: NO_STORE });
  }

  try {
    if (await vibeRateLimited(request, "login", email)) {
      return NextResponse.json({ error: "too_many_attempts_try_again_later" }, { status: 429, headers: { ...NO_STORE, "Retry-After": "900" } });
    }
    const user = await prisma.user.findUnique({
      where: { email },
      select: { id: true, isActive: true, passwordHash: true, emailVerifiedAt: true, mfaEnrolled: true, mfaSecretEnc: true },
    });
    if (!user?.isActive || !user.passwordHash || !verifyPassword(password, user.passwordHash)) {
      return NextResponse.json({ error: "invalid_credentials" }, { status: 401, headers: NO_STORE });
    }

    const memberships = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${user.id}, true)`;
      return tx.userCompany.findMany({
        where: { userId: user.id },
        select: { role: true, company: { select: { slug: true } } },
      });
    });
    const isCeo = memberships.some((membership) => membership.company.slug === "hq" && membership.role === "ceo");
    const hasBusinessAccess = memberships.some((membership) =>
      (VIBE_BUSINESS_TARGETS as readonly string[]).includes(membership.company.slug) &&
      ["customer", "staff", "admin"].includes(membership.role),
    );
    if (!isCeo && !hasBusinessAccess) return NextResponse.json({ error: "business_access_not_found" }, { status: 403, headers: NO_STORE });
    if (!isCeo && !user.emailVerifiedAt) return NextResponse.json({ error: "email_verification_required" }, { status: 403, headers: NO_STORE });

    if (isCeo && (!user.mfaEnrolled || !user.mfaSecretEnc)) {
      return NextResponse.json({ error: "ceo_mfa_must_be_enrolled_before_access" }, { status: 403, headers: NO_STORE });
    }
    if (user.mfaEnrolled) {
      let verified = false;
      if (mfaCode && user.mfaSecretEnc) {
        try { verified = verifyTotp(decryptMfaSecret(user.mfaSecretEnc), mfaCode, Math.floor(Date.now() / 1000)); }
        catch { verified = false; }
      }
      const compactRecoveryCode = recoveryCode.replace(/-/g, "");
      const validRecoveryFormat = /^[A-F0-9]{16}$/i.test(compactRecoveryCode) &&
        (/^[A-F0-9]{16}$/i.test(recoveryCode) || /^[A-F0-9]{4}(?:-[A-F0-9]{4}){3}$/i.test(recoveryCode));
      if (!verified && validRecoveryFormat) {
        verified = await prisma.$transaction(async (tx) => {
          await tx.$queryRaw`SELECT set_config('app.user_id', ${user.id}, true)`;
          const formatted = compactRecoveryCode.length === 16
            ? `${compactRecoveryCode.slice(0, 4)}-${compactRecoveryCode.slice(4, 8)}-${compactRecoveryCode.slice(8, 12)}-${compactRecoveryCode.slice(12, 16)}`.toUpperCase()
            : recoveryCode.toUpperCase();
          const hashes = [...new Set([sha256(recoveryCode), sha256(recoveryCode.toLowerCase()), sha256(recoveryCode.toUpperCase()), sha256(compactRecoveryCode.toLowerCase()), sha256(formatted)])];
          const saved = await tx.recoveryCode.findFirst({
            where: { userId: user.id, codeHash: { in: hashes }, usedAt: null },
            select: { id: true },
          });
          if (!saved) return false;
          const consumed = await tx.recoveryCode.updateMany({
            where: { id: saved.id, usedAt: null },
            data: { usedAt: new Date() },
          });
          return consumed.count === 1;
        });
      }
      if (!verified) return NextResponse.json({ error: "invalid_credentials" }, { status: 401, headers: NO_STORE });
    }

    const token = newSessionToken();
    const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1000);
    await prisma.session.create({ data: { userId: user.id, tokenHash: sha256(token), expiresAt } });
    const response = NextResponse.json({ ok: true, expiresAt }, { headers: NO_STORE });
    response.cookies.set(VIBE_SESSION_COOKIE, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      path: "/",
      expires: expiresAt,
    });
    return response;
  } catch {
    return NextResponse.json({ error: "identity_service_unavailable" }, { status: 503, headers: NO_STORE });
  }
}
