import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Stock Market Express",
  description: "Market intelligence, research, watchlists, portfolio tracking and paper trading.",
  openGraph: { title: "Stock Market Express", description: "Market intelligence, research, watchlists, portfolio tracking and paper trading." },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en-GB"><body>{children}</body></html>);
}
