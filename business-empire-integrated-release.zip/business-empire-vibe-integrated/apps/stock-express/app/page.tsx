'use client';
import Link from "next/link";
import { useState } from "react";

const SERVICES = ["Research & intelligence","Watchlists","Portfolio tracking","Alerts","Paper trading"];

export default function Home() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState<null | "ok" | "err">(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setSent(null);
    try {
      const res = await fetch("/api/enquiry", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email }),
      });
      setSent(res.ok ? "ok" : "err");
    } catch { setSent("err"); }
    finally { setBusy(false); }
  }

  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 900, margin: "0 auto", padding: 24 }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1 style={{ color: "#B45309" }}>Stock Market Express</h1>
        <nav style={{ display: "flex", gap: 16 }}>
          <Link href="/dashboard">Customer dashboard</Link>
          <Link href="/admin">Business admin</Link>
          <Link href="/login">Sign in</Link>
          <a href={process.env.NEXT_PUBLIC_VIBE_PLATFORM_URL ?? "http://localhost:3008"} target="_blank" rel="noreferrer">Vibe Coding Studio</a>
        </nav>
      </header>
      <p>Market intelligence, research, watchlists, portfolio tracking and paper trading.</p>
      <p style={{ background: "#FEF3C7", padding: 12, borderRadius: 8 }}><strong>Important:</strong> Paper trading only. Live brokerage integration requires an appropriately authorised partner and is currently disabled.</p>
      <h2>Services</h2>
      <ul>{SERVICES.map((s) => <li key={s}>{s}</li>)}</ul>
      <h2>Contact us</h2>
      <form onSubmit={submit} aria-label="Enquiry form">
        <input
          type="email" required placeholder="your@email.com" value={email}
          onChange={(e) => setEmail(e.target.value)} aria-label="Email address"
        />
        <button type="submit" disabled={busy}>{busy ? "Sending…" : "Request a callback"}</button>
      </form>
      {sent === "ok" && <p role="status">Thanks — we received your enquiry.</p>}
      {sent === "err" && <p role="alert" style={{ color: "#B91C1C" }}>Something went wrong. Please try again.</p>}
      <footer style={{ marginTop: 40, fontSize: 13, display: "flex", gap: 16 }}>
        <a href="/legal/privacy">Privacy policy</a>
        <a href="/legal/terms">Terms of service</a>
        <span>Support: support@stock-express.example.com</span>
      </footer>
    </main>
  );
}
