import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { withTenantSession, type TenantRole } from "@empire/db";

const COMPANY_SLUG = "real-estate";
const SESSION_COOKIE = "empire_real_estate_session";
const NO_STORE = { "Cache-Control": "no-store" };

/** Fixed-company API gate. Never accepts a company ID or role from the request. */
export async function tenantApiGate(allowedRoles: readonly TenantRole[]) {
  const token = cookies().get(SESSION_COOKIE)?.value;
  try {
    const result = await withTenantSession(
      { token, companySlug: COMPANY_SLUG, allowedRoles },
      async () => true,
    );
    if (!result.ok) {
      return NextResponse.json(
        { error: result.error },
        { status: result.status, headers: NO_STORE },
      );
    }
    // Authentication and tenant scope are now verified, but this endpoint's
    // business data contract is deliberately not fabricated in this phase.
    return NextResponse.json(
      { error: "tenant_endpoint_not_implemented" },
      { status: 503, headers: NO_STORE },
    );
  } catch {
    // Fail closed on database/RLS errors; never fall back to an unscoped query.
    return NextResponse.json(
      { error: "tenant_service_unavailable" },
      { status: 503, headers: NO_STORE },
    );
  }
}
