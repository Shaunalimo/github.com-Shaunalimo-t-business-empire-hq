import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Real Estate Master Developments",
  description: "Property listings, development, rentals, tenant management and portfolio tools.",
  openGraph: { title: "Real Estate Master Developments", description: "Property listings, development, rentals, tenant management and portfolio tools." },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en-GB"><body>{children}</body></html>);
}
