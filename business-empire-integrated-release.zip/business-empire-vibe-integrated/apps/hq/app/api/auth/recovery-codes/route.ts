import { randomBytes } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { decryptMfaSecret, isSameOriginRequest, sha256, verifyTotp } from "@empire/core";
import { currentHqUser } from "../session";
export const runtime = "nodejs";
function makeCode() { const b = randomBytes(8).toString("hex").toUpperCase(); return `${b.slice(0,4)}-${b.slice(4,8)}-${b.slice(8,12)}-${b.slice(12,16)}`; }
export async function POST(request: NextRequest) {
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "Invalid request origin" }, { status: 403, headers: { "Cache-Control": "no-store" } });
  const user = await currentHqUser();
  if (!user) return NextResponse.json({ error: "Unauthorised" }, { status: 401, headers: { "Cache-Control": "no-store" } });
  const body = await request.json().catch(() => ({}));
  const code = typeof body.code === "string" ? body.code.trim() : "";
  const record = await prisma.user.findUnique({ where: { id: user.id }, select: { mfaSecretEnc: true, mfaEnrolled: true } });
  let valid = false;
  try { valid = !!record?.mfaEnrolled && !!record.mfaSecretEnc && verifyTotp(decryptMfaSecret(record.mfaSecretEnc), code, Math.floor(Date.now()/1000)); } catch { valid = false; }
  if (!valid) return NextResponse.json({ error: "Current authenticator code is invalid" }, { status: 401, headers: { "Cache-Control": "no-store" } });
  const codes = Array.from({ length: 10 }, makeCode);
  await prisma.$transaction(async tx => {
    await tx.$queryRaw`SELECT set_config('app.user_id', ${user.id}, true)`;
    await tx.$queryRaw`SELECT set_config('app.company_id', ${user.companyId}, true)`;
    await tx.recoveryCode.deleteMany({ where: { userId: user.id } });
    await tx.recoveryCode.createMany({ data: codes.map(c => ({ userId: user.id, codeHash: sha256(c) })) });
    await tx.auditLog.create({ data: { actorId: user.id, companyId: user.companyId, action: "hq.recovery_codes.rotated", subject: user.id } });
  });
  return NextResponse.json({ codes, warning: "Shown once. Store offline securely. Generating these codes invalidates all previous recovery codes." }, { headers: { "Cache-Control": "no-store, private" } });
}
