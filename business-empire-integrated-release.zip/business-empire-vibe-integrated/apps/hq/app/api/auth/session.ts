import { cookies } from "next/headers";
import { prisma } from "@empire/db";
import { sha256 } from "@empire/core";

export const SESSION_COOKIE = "empire_hq_session";

/** Resolve the HQ CEO identity under the same transaction-local RLS context
 * used by the tenant APIs. The cookie token is never trusted as a user ID. */
export async function currentHqUser() {
  const token = cookies().get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const session = await prisma.session.findUnique({
    where: { tokenHash: sha256(token) },
    select: { id: true, userId: true, expiresAt: true, revokedAt: true },
  });
  if (!session || session.revokedAt || session.expiresAt <= new Date()) return null;

  return prisma.$transaction(async (tx) => {
    await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
    const user = await tx.user.findUnique({
      where: { id: session.userId },
      select: { id: true, email: true, isActive: true },
    });
    if (!user?.isActive) return null;

    const membership = await tx.userCompany.findFirst({
      where: { userId: user.id, role: "ceo", company: { slug: "hq" } },
      select: { companyId: true },
    });
    if (!membership) return null;

    await tx.$queryRaw`SELECT set_config('app.company_id', ${membership.companyId}, true)`;
    return { id: user.id, email: user.email, sessionId: session.id, companyId: membership.companyId };
  });
}
