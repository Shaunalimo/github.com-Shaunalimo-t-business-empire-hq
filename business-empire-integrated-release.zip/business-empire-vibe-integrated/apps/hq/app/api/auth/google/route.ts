import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { isSameOriginRequest, verifyGoogleIdToken } from "@empire/core";
export const runtime = "nodejs";
export async function POST(request: NextRequest) {
  const noStore = { "Cache-Control": "no-store" };
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "Invalid request origin" }, { status: 403, headers: noStore });
  try {
    const body = await request.json();
    const credential = typeof body.credential === "string" ? body.credential : "";
    if (!credential || credential.length > 16_384) return NextResponse.json({ error: "Google credential required" }, { status: 400, headers: noStore });
    const identity = await verifyGoogleIdToken(credential);
    return NextResponse.json({ error: "Google identity verified, but CEO console login still requires enrolled MFA. Sign in with password + authenticator; customer Google sign-in is enabled in business workspaces." }, { status: 403, headers: noStore });
  } catch { return NextResponse.json({ error: "Google sign-in unavailable or identity token invalid" }, { status: 401, headers: noStore }); }
}
