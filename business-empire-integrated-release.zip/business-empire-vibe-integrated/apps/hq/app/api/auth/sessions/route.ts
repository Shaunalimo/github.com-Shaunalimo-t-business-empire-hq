import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@empire/db";
import { sha256, isSameOriginRequest } from "@empire/core";
import { currentHqUser, SESSION_COOKIE } from "../session";

export const runtime = "nodejs";
export async function GET() {
  const user = await currentHqUser();
  if (!user) return NextResponse.json({ error: "Unauthorised" }, { status: 401, headers: { "Cache-Control": "no-store" } });
  const sessions = await prisma.session.findMany({ where: { userId: user.id, revokedAt: null, expiresAt: { gt: new Date() } }, orderBy: { createdAt: "desc" }, select: { id: true, createdAt: true, expiresAt: true } });
  return NextResponse.json({ sessions: sessions.map(s => ({ ...s, current: s.id === user.sessionId })) }, { headers: { "Cache-Control": "no-store" } });
}

export async function DELETE(request: NextRequest) {
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "Invalid request origin" }, { status: 403, headers: { "Cache-Control": "no-store" } });
  const user = await currentHqUser();
  if (!user) return NextResponse.json({ error: "Unauthorised" }, { status: 401, headers: { "Cache-Control": "no-store" } });
  const body = await request.json().catch(() => ({}));
  const sessionId = typeof body.sessionId === "string" ? body.sessionId : "";
  if (!sessionId) return NextResponse.json({ error: "sessionId is required" }, { status: 400 });
  if (sessionId === user.sessionId) return NextResponse.json({ error: "Use sign out to revoke the current session" }, { status: 400 });
  const result = await prisma.$transaction(async tx => {
    await tx.$queryRaw`SELECT set_config('app.user_id', ${user.id}, true)`;
    await tx.$queryRaw`SELECT set_config('app.company_id', ${user.companyId}, true)`;
    const revoked = await tx.session.updateMany({ where: { id: sessionId, userId: user.id, revokedAt: null }, data: { revokedAt: new Date() } });
    if (revoked.count) await tx.auditLog.create({ data: { actorId: user.id, companyId: user.companyId, action: "hq.session.revoked", subject: sessionId } });
    return revoked;
  });
  return NextResponse.json({ ok: true, revoked: result.count === 1 }, { headers: { "Cache-Control": "no-store" } });
}
