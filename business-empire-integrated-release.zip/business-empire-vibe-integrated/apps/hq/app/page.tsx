'use client';
import Link from "next/link";
import { useEffect, useState } from "react";

const BUSINESSES = [
  { id: "growthboost", name: "GrowthBoost AI", color: "#7C3AED", port: 3001 },
  { id: "ai-magazine", name: "AI Magazine & Comic Book Studio", color: "#DB2777", port: 3002 },
  { id: "trust-vault", name: "Trust Vault Bank", color: "#0F766E", port: 3003 },
  { id: "stock-express", name: "Stock Market Express", color: "#B45309", port: 3004 },
  { id: "real-estate", name: "Real Estate Master Developments", color: "#1D4ED8", port: 3005 },
  { id: "supergpu", name: "SUPERGPU UNIVERSAL", color: "#DC2626", port: 3006 },
  { id: "dailyaccess", name: "DailyAccess", color: "#047857", port: 3007 },
];

type Consolidated = { status?: string; code?: string; message?: string; };

export default function HQ() {
  const [data, setData] = useState<Consolidated | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const [briefing, setBriefing] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/consolidated")
      .then(async (r) => { const d = await r.json(); setData(d); setState(r.ok ? "ready" : "error"); })
      .catch(() => setState("error"));
  }, []);

  async function dailyBriefing() {
    const res = await fetch("/api/consolidated", { cache: "no-store" });
    const d = await res.json();
    setBriefing(d.message ?? "The briefing service is not configured yet.");
  }

  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 1100, margin: "0 auto", padding: 24 }}>
      <header style={{ display: "flex", justifyContent: "space-between" }}>
        <h1>CEO Master Dashboard</h1>
        <nav style={{ display: "flex", gap: 16 }}>
          <Link href="/reports">Reports</Link>
          <Link href="/staff">Staff & permissions</Link>
          <Link href="/security">Security & audit</Link>
          <Link href="/login">CEO sign-in setup</Link>
          <a href={process.env.NEXT_PUBLIC_VIBE_PLATFORM_URL ?? "http://localhost:3008"} target="_blank" rel="noreferrer">Vibe Coding Platform</a>
        </nav>
      </header>

      <h2>Business overview</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 12 }}>
        {BUSINESSES.map((b) => (
          <div key={b.id} style={{ border: "1px solid #E5E7EB", borderRadius: 12, padding: 16 }}>
            <h3 style={{ color: b.color }}>{b.name}</h3>
            <p style={{ fontSize: 13 }}>Local development: <a href={`http://localhost:${b.port}`} target="_blank" rel="noreferrer">Open {b.name}</a></p>
            <p style={{ fontSize: 13 }}>Production domain: not configured. Register a domain, configure DNS and TLS before publishing.</p>
            <p style={{ fontSize: 13 }}>Business status and financial reporting will appear after authenticated service integrations are deployed.</p>
          </div>
        ))}
      </div>

      <h2>Vibe Coding Platform</h2>
      <p>Shared website and application studio for all seven businesses. <a href={process.env.NEXT_PUBLIC_VIBE_PLATFORM_URL ?? "http://localhost:3008"} target="_blank" rel="noreferrer">Open Vibe Coding Platform</a></p>

      <h2>Consolidated reporting (GBP)</h2>
      {state === "loading" && <p>Loading…</p>}
      {state === "error" && <p role="alert" style={{ background: "#FEF3C7", padding: 12, borderRadius: 8 }}>{data?.message ?? "Reporting is unavailable. Configure CEO authentication and the live ledger before enabling this panel."}</p>}
      {state === "ready" && <p role="status">{data?.message ?? "Reporting service connected."}</p>}
      <p style={{ fontSize: 13, color: "#555" }}>Financial figures are intentionally withheld until CEO authentication, MFA, authorisation and live ledger integration are verified. No sample figures are presented as real.</p>

      <h2>AI CEO assistant & daily briefing</h2>
      <button onClick={dailyBriefing}>Generate today&apos;s briefing</button>
      {briefing && <p role="status" style={{ background: "#EEF2FF", padding: 12, borderRadius: 8 }}>{briefing}</p>}

      <h2>Treasury & intercompany</h2>
      <p>Money never moves between companies without a board-approved authorisation reference recorded against an intercompany journal pair (see the financial controls documentation).</p>
    </main>
  );
}
