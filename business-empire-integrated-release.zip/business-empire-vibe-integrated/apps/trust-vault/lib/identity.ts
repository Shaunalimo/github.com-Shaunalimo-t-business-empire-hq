import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { hashPassword, verifyPassword, newSessionToken, sha256, isSameOriginRequest, verifyTotp, verifyGoogleIdToken } from "@empire/core";
import { decryptMfaSecret, encryptMfaSecret } from "@empire/core";
import { generateTotpSecret } from "@empire/core";
import { randomBytes } from "node:crypto";

export const COMPANY_SLUG = "trust-vault";
export const SESSION_COOKIE = "empire_trust_vault_session";
const NO_STORE = { "Cache-Control": "no-store" };
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Shared database-backed throttle. Use the reverse proxy's real client IP, never a client-supplied X-Forwarded-For value. */
async function customerRateLimited(req: Request, action: string, subject = "") {
  const ip = req.headers.get("x-real-ip") || "unknown";
  const key = sha256(`customer-auth:${action}:${ip}:${subject}`);
  const now = new Date();
  const windowMs = 15 * 60 * 1000;
  const current = await prisma.authThrottle.findUnique({ where: { key }, select: { windowStartedAt: true, attempts: true, lockedUntil: true } });
  if (current?.lockedUntil && current.lockedUntil > now) return true;
  const expired = !current || now.getTime() - current.windowStartedAt.getTime() >= windowMs;
  const attempts = expired ? 1 : (current?.attempts || 0) + 1;
  const lockedUntil = attempts >= 8 ? new Date(now.getTime() + 15 * 60 * 1000) : null;
  await prisma.authThrottle.upsert({
    where: { key },
    create: { key, windowStartedAt: now, attempts, lockedUntil },
    update: { windowStartedAt: expired ? now : current!.windowStartedAt, attempts, lockedUntil },
  });
  return Boolean(lockedUntil);
}

export function rejectCrossOrigin(req: Request) {
  if (!isSameOriginRequest(req.headers)) return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers: NO_STORE });
  return null;
}
function issueCookie(response: NextResponse, token: string) {
  response.cookies.set(SESSION_COOKIE, token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", maxAge: 60 * 60 * 8 });
  return response;
}

/** Register one customer in this fixed business only. The caller cannot choose a company or role. */
export async function registerCustomer(req: Request) {
  if (process.env.CUSTOMER_REGISTRATION_ENABLED !== "true") return NextResponse.json({ error: "registration_not_enabled" }, { status: 503, headers: NO_STORE });
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  if (await customerRateLimited(req, "register")) return NextResponse.json({ error: "too_many_attempts_try_again_later" }, { status: 429, headers: NO_STORE });
  const body = await req.json().catch(() => null);
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  if (!EMAIL.test(email) || email.length > 254 || password.length < 12 || password.length > 256) {
    return NextResponse.json({ error: "valid_email_and_password_minimum_12_characters_required" }, { status: 400, headers: NO_STORE });
  }
  try {
    const company = await prisma.company.findUnique({ where: { slug: COMPANY_SLUG }, select: { id: true } });
    if (!company) return NextResponse.json({ error: "identity_service_unavailable" }, { status: 503, headers: NO_STORE });
    const result = await prisma.$transaction(async tx => {
      const existing = await tx.user.findUnique({ where: { email }, select: { id: true, passwordHash: true, isActive: true } });
      if (existing && (!existing.isActive || !existing.passwordHash || !verifyPassword(password, existing.passwordHash))) return { invalidExisting: true as const };
      const user = existing ?? await tx.user.create({ data: { email, passwordHash: hashPassword(password) } });
      await tx.$queryRaw`SELECT set_config('app.user_id', ${user.id}, true)`;
      const membership = await tx.userCompany.findFirst({ where: { userId: user.id, companyId: company.id }, select: { id: true } });
      if (membership) return { duplicate: true as const };
      await tx.userCompany.create({ data: { userId: user.id, companyId: company.id, role: "customer" } });
      await tx.$queryRaw`SELECT set_config('app.company_id', ${company.id}, true)`;
      await tx.auditLog.create({ data: { actorId: user.id, companyId: company.id, action: existing ? "customer.business_access_added" : "customer.registered", subject: user.id } });
      return { duplicate: false as const, userId: user.id };
    });
    if ("invalidExisting" in result && result.invalidExisting) return NextResponse.json({ error: "invalid_credentials" }, { status: 401, headers: NO_STORE });
    if ("duplicate" in result && result.duplicate) return NextResponse.json({ error: "business_account_already_exists_use_sign_in" }, { status: 409, headers: NO_STORE });
    return NextResponse.json({ ok: true, userId: result.userId, company: COMPANY_SLUG, notice: "Verify your email before signing in. Request a verification message using the email verification endpoint." }, { status: 201, headers: NO_STORE });
  } catch { return NextResponse.json({ error: "registration_unavailable" }, { status: 503, headers: NO_STORE }); }
}

/** Sign in or provision an account using a Google ID token verified on this server. */
export async function googleCustomerSignIn(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  const body = await req.json().catch(() => null);
  const credential = typeof body?.credential === "string" ? body.credential : "";
  if (!credential) return NextResponse.json({ error: "google_credential_required" }, { status: 400, headers: NO_STORE });
  let identity;
  try { identity = await verifyGoogleIdToken(credential); } catch { return NextResponse.json({ error: "google_sign_in_unavailable_or_invalid" }, { status: 401, headers: NO_STORE }); }
  try {
    const company = await prisma.company.findUnique({ where: { slug: COMPANY_SLUG }, select: { id: true } });
    if (!company) return NextResponse.json({ error: "identity_service_unavailable" }, { status: 503, headers: NO_STORE });
    const result = await prisma.$transaction(async tx => {
      const user = await tx.user.upsert({ where: { email: identity.email }, create: { email: identity.email, emailVerifiedAt: new Date() }, update: { emailVerifiedAt: new Date() }, select: { id: true, isActive: true } });
      if (!user.isActive) return null;
      await tx.$queryRaw`SELECT set_config('app.user_id', ${user.id}, true)`;
      const membership = await tx.userCompany.findFirst({ where: { userId: user.id, companyId: company.id }, select: { id: true, role: true } });
      if (!membership) await tx.userCompany.create({ data: { userId: user.id, companyId: company.id, role: "customer" } });
      else if (membership.role !== "customer") return null;
      await tx.$queryRaw`SELECT set_config('app.company_id', ${company.id}, true)`;
      const raw = newSessionToken();
      await tx.session.create({ data: { userId: user.id, tokenHash: sha256(raw), expiresAt: new Date(Date.now() + 8 * 60 * 60 * 1000) } });
      await tx.auditLog.create({ data: { actorId: user.id, companyId: company.id, action: "customer.google_sign_in", subject: user.id } });
      return { userId: user.id, raw };
    });
    if (!result) return NextResponse.json({ error: "account_not_allowed" }, { status: 403, headers: NO_STORE });
    return issueCookie(NextResponse.json({ ok: true, userId: result.userId }, { headers: NO_STORE }), result.raw);
  } catch { return NextResponse.json({ error: "google_sign_in_unavailable" }, { status: 503, headers: NO_STORE }); }
}

export async function loginCustomer(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  if (await customerRateLimited(req, "login")) return NextResponse.json({ error: "invalid_credentials" }, { status: 429, headers: NO_STORE });
  const body = await req.json().catch(() => null);
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  const password = typeof body?.password === "string" ? body.password : "";
  if (!EMAIL.test(email) || password.length > 256 || !password) return NextResponse.json({ error: "invalid_credentials" }, { status: 401, headers: NO_STORE });
  try {
    const user = await prisma.user.findUnique({ where: { email }, select: { id: true, passwordHash: true, isActive: true, mfaEnrolled: true, mfaSecretEnc: true, emailVerifiedAt: true } });
    if (!user?.isActive || !user.passwordHash || !user.emailVerifiedAt || !verifyPassword(password, user.passwordHash)) return NextResponse.json({ error: "invalid_credentials" }, { status: 401, headers: NO_STORE });
    if (user.mfaEnrolled) {
      const code = typeof body?.mfaCode === "string" ? body.mfaCode : "";
      const recoveryCode = typeof body?.recoveryCode === "string" ? body.recoveryCode.trim() : "";
      let verified = false;
      if (code && user.mfaSecretEnc) {
        try { verified = verifyTotp(decryptMfaSecret(user.mfaSecretEnc), code, Math.floor(Date.now() / 1000)); } catch { verified = false; }
      }
      if (!verified && recoveryCode) {
        const hash = sha256(recoveryCode);
        const saved = await prisma.recoveryCode.findFirst({ where: { userId: user.id, codeHash: hash, usedAt: null }, select: { id: true } });
        if (saved) { const consumed = await prisma.recoveryCode.updateMany({ where: { id: saved.id, usedAt: null }, data: { usedAt: new Date() } }); verified = consumed.count === 1; }
      }
      if (!verified) return NextResponse.json({ error: "invalid_credentials" }, { status: 401, headers: NO_STORE });
    }
    const membership = await prisma.userCompany.findFirst({ where: { userId: user.id, company: { slug: COMPANY_SLUG } }, select: { companyId: true } });
    if (!membership) return NextResponse.json({ error: "business_access_not_found" }, { status: 403, headers: NO_STORE });
    const token = newSessionToken();
    await prisma.session.create({ data: { userId: user.id, tokenHash: sha256(token), expiresAt: new Date(Date.now() + 8 * 60 * 60 * 1000) } });
    return issueCookie(NextResponse.json({ ok: true, company: COMPANY_SLUG }, { headers: NO_STORE }), token);
  } catch { return NextResponse.json({ error: "identity_service_unavailable" }, { status: 503, headers: NO_STORE }); }
}

async function deliverCustomerEmail(to: string, subject: string, textBody: string) {
  const endpoint = process.env.AUTH_EMAIL_WEBHOOK_URL;
  const secret = process.env.AUTH_EMAIL_WEBHOOK_SECRET;
  if (!process.env.PUBLIC_APP_URL || !endpoint || !secret) throw new Error("Verified email delivery is not configured");
  const response = await fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${secret}` }, body: JSON.stringify({ to, subject, text: textBody, application: COMPANY_SLUG }), cache: "no-store" });
  if (!response.ok) throw new Error("Email provider rejected delivery");
}

/** Generic response prevents account enumeration; delivery is delegated to a configured server-side provider. */
export async function requestCustomerEmailVerification(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  if (await customerRateLimited(req, "email-verification")) return NextResponse.json({ ok: true, message: "If the account needs verification, an email will be sent when delivery is configured." }, { headers: NO_STORE });
  const body = await req.json().catch(() => null);
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  if (!EMAIL.test(email) || email.length > 254) return NextResponse.json({ error: "request_received_if_account_requires_verification_email_will_be_sent" }, { headers: NO_STORE });
  try {
    const user = await prisma.user.findUnique({ where: { email }, select: { id: true, emailVerifiedAt: true, isActive: true } });
    if (user?.isActive && !user.emailVerifiedAt) {
      const raw = newSessionToken();
      await prisma.emailVerificationToken.create({ data: { userId: user.id, tokenHash: sha256(raw), expiresAt: new Date(Date.now() + 30 * 60 * 1000) } });
      const url = `${process.env.PUBLIC_APP_URL || ""}/verify-email?token=${encodeURIComponent(raw)}`;
      await deliverCustomerEmail(email, "Verify your Business Empire account", `Verify your ${COMPANY_SLUG} account within 30 minutes: ${url}`);
    }
  } catch { /* Deliberately keep the same public response to prevent account discovery. */ }
  return NextResponse.json({ ok: true, message: "If the account needs verification, an email will be sent when delivery is configured." }, { headers: NO_STORE });
}

export async function verifyCustomerEmail(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  const body = await req.json().catch(() => null);
  const token = typeof body?.token === "string" ? body.token : "";
  if (token.length < 20 || token.length > 256) return NextResponse.json({ error: "verification_link_invalid_or_expired" }, { status: 400, headers: NO_STORE });
  try {
    const record = await prisma.emailVerificationToken.findUnique({ where: { tokenHash: sha256(token) }, select: { id: true, userId: true, expiresAt: true, usedAt: true } });
    if (!record || record.usedAt || record.expiresAt <= new Date()) return NextResponse.json({ error: "verification_link_invalid_or_expired" }, { status: 400, headers: NO_STORE });
    const updated = await prisma.$transaction(async tx => {
      const consumed = await tx.emailVerificationToken.updateMany({ where: { id: record.id, usedAt: null, expiresAt: { gt: new Date() } }, data: { usedAt: new Date() } });
      if (consumed.count !== 1) return false;
      await tx.user.update({ where: { id: record.userId }, data: { emailVerifiedAt: new Date() } });
      return true;
    });
    if (!updated) return NextResponse.json({ error: "verification_link_invalid_or_expired" }, { status: 400, headers: NO_STORE });
    return NextResponse.json({ ok: true, message: "Email verified. You can now sign in." }, { headers: NO_STORE });
  } catch { return NextResponse.json({ error: "verification_unavailable" }, { status: 503, headers: NO_STORE }); }
}

/** Start customer MFA enrolment. The secret is encrypted at rest and shown once to the authenticated customer. */
export async function startCustomerMfa(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  const customer = await currentCustomer();
  if (!customer) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  try {
    const body = await req.json().catch(() => null);
    const existing = await prisma.user.findUnique({ where: { id: customer.id }, select: { mfaEnrolled: true, mfaSecretEnc: true } });
    if (existing?.mfaEnrolled) {
      const oldCode = typeof body?.currentCode === "string" ? body.currentCode : "";
      if (!existing.mfaSecretEnc || !verifyTotp(decryptMfaSecret(existing.mfaSecretEnc), oldCode, Math.floor(Date.now() / 1000))) return NextResponse.json({ error: "current_authenticator_code_required" }, { status: 403, headers: NO_STORE });
    }
    const secret = generateTotpSecret();
    await prisma.user.update({ where: { id: customer.id }, data: { mfaSecretEnc: encryptMfaSecret(secret), mfaEnrolled: false } });
    const label = encodeURIComponent(`${COMPANY_SLUG}:${customer.email}`);
    const issuer = encodeURIComponent("Business Empire");
    const otpauth = `otpauth://totp/${label}?secret=${secret}&issuer=${issuer}&algorithm=SHA1&digits=6&period=30`;
    return NextResponse.json({ secret, otpauth }, { headers: NO_STORE });
  } catch { return NextResponse.json({ error: "mfa_setup_unavailable_check_encryption_configuration" }, { status: 503, headers: NO_STORE }); }
}

/** Confirm possession of the authenticator before enabling MFA. */
export async function confirmCustomerMfa(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  const customer = await currentCustomer();
  if (!customer) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const body = await req.json().catch(() => null);
  const code = typeof body?.code === "string" ? body.code : "";
  try {
    const user = await prisma.user.findUnique({ where: { id: customer.id }, select: { mfaSecretEnc: true } });
    if (!user?.mfaSecretEnc || !verifyTotp(decryptMfaSecret(user.mfaSecretEnc), code, Math.floor(Date.now() / 1000))) return NextResponse.json({ error: "invalid_authenticator_code" }, { status: 400, headers: NO_STORE });
    await prisma.user.update({ where: { id: customer.id }, data: { mfaEnrolled: true } });
    const company = await prisma.company.findUnique({ where: { slug: COMPANY_SLUG }, select: { id: true } });
    if (company) await prisma.$transaction(async tx => {
      await tx.$queryRaw`SELECT set_config('app.user_id', ${customer.id}, true)`;
      await tx.$queryRaw`SELECT set_config('app.company_id', ${company.id}, true)`;
      await tx.auditLog.create({ data: { actorId: customer.id, companyId: company.id, action: "customer.mfa_enabled", subject: customer.id } });
    });
    return NextResponse.json({ ok: true, recoveryCodesAvailable: true }, { headers: NO_STORE });
  } catch { return NextResponse.json({ error: "mfa_confirmation_unavailable" }, { status: 503, headers: NO_STORE }); }
}

/** Issue one-time recovery codes. Existing unused codes are replaced; plaintext is returned once only. */
export async function rotateCustomerRecoveryCodes(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  const customer = await currentCustomer();
  if (!customer) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const body = await req.json().catch(() => null);
  const code = typeof body?.code === "string" ? body.code : "";
  try {
    const user = await prisma.user.findUnique({ where: { id: customer.id }, select: { mfaSecretEnc: true, mfaEnrolled: true } });
    if (!user?.mfaEnrolled || !user.mfaSecretEnc || !verifyTotp(decryptMfaSecret(user.mfaSecretEnc), code, Math.floor(Date.now() / 1000))) return NextResponse.json({ error: "valid_mfa_code_required" }, { status: 403, headers: NO_STORE });
    const codes = Array.from({ length: 10 }, () => randomBytes(8).toString("hex"));
    await prisma.$transaction(async tx => {
      await tx.recoveryCode.deleteMany({ where: { userId: customer.id, usedAt: null } });
      await tx.recoveryCode.createMany({ data: codes.map(value => ({ userId: customer.id, codeHash: sha256(value) })) });
    });
    return NextResponse.json({ ok: true, recoveryCodes: codes, warning: "Save these codes securely. They are displayed once and cannot be retrieved again." }, { headers: NO_STORE });
  } catch { return NextResponse.json({ error: "recovery_codes_unavailable" }, { status: 503, headers: NO_STORE }); }
}


/** Generic password-reset request; never reveals whether an email is registered. */
export async function requestCustomerPasswordReset(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  if (await customerRateLimited(req, "password-reset")) return NextResponse.json({ ok: true, message: "If an eligible account exists, reset instructions will be sent." }, { headers: NO_STORE });
  const body = await req.json().catch(() => null);
  const email = typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  try {
    if (EMAIL.test(email) && email.length <= 254) {
      const user = await prisma.user.findUnique({ where: { email }, select: { id: true, isActive: true, emailVerifiedAt: true } });
      if (user?.isActive && user.emailVerifiedAt) {
        const raw = newSessionToken();
        await prisma.passwordResetToken.create({ data: { userId: user.id, tokenHash: sha256(raw), expiresAt: new Date(Date.now() + 30 * 60 * 1000) } });
        const url = String(process.env.PUBLIC_APP_URL || "") + "/reset-password?token=" + encodeURIComponent(raw);
        await deliverCustomerEmail(email, "Reset your Business Empire password", "Use this one-time link within 30 minutes: " + url + "\nIf you did not request this, ignore this email.");
      }
    }
    return NextResponse.json({ ok: true, message: "If an eligible account exists, reset instructions will be sent." }, { headers: NO_STORE });
  } catch {
    return NextResponse.json({ ok: true, message: "If an eligible account exists, reset instructions will be sent." }, { headers: NO_STORE });
  }
}

/** Consume a single-use reset token and revoke every existing session. */
export async function confirmCustomerPasswordReset(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  if (await customerRateLimited(req, "password-reset-confirm")) return NextResponse.json({ error: "reset_link_invalid_or_expired" }, { status: 400, headers: NO_STORE });
  const body = await req.json().catch(() => null);
  const token = typeof body?.token === "string" ? body.token : "";
  const password = typeof body?.password === "string" ? body.password : "";
  if (token.length < 32 || token.length > 256 || password.length < 12 || password.length > 256) return NextResponse.json({ error: "reset_link_invalid_or_expired_or_password_invalid" }, { status: 400, headers: NO_STORE });
  try {
    const record = await prisma.passwordResetToken.findUnique({ where: { tokenHash: sha256(token) }, select: { id: true, userId: true, expiresAt: true, usedAt: true } });
    if (!record || record.usedAt || record.expiresAt <= new Date()) return NextResponse.json({ error: "reset_link_invalid_or_expired" }, { status: 400, headers: NO_STORE });
    const done = await prisma.$transaction(async tx => {
      const consumed = await tx.passwordResetToken.updateMany({ where: { id: record.id, usedAt: null, expiresAt: { gt: new Date() } }, data: { usedAt: new Date() } });
      if (consumed.count !== 1) return false;
      await tx.user.update({ where: { id: record.userId }, data: { passwordHash: hashPassword(password) } });
      await tx.session.updateMany({ where: { userId: record.userId, revokedAt: null }, data: { revokedAt: new Date() } });
      await tx.passwordResetToken.updateMany({ where: { userId: record.userId, id: { not: record.id }, usedAt: null }, data: { usedAt: new Date() } });
      return true;
    });
    if (!done) return NextResponse.json({ error: "reset_link_invalid_or_expired" }, { status: 400, headers: NO_STORE });
    return NextResponse.json({ ok: true, message: "Password updated. Sign in again on your devices." }, { headers: NO_STORE });
  } catch { return NextResponse.json({ error: "password_reset_unavailable" }, { status: 503, headers: NO_STORE }); }
}

/** List session metadata only; raw tokens are never returned. */
export async function listCustomerSessions() {
  const customer = await currentCustomer();
  if (!customer) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const current = cookies().get(SESSION_COOKIE)?.value || "";
  try {
    const rows = await prisma.session.findMany({ where: { userId: customer.id, revokedAt: null, expiresAt: { gt: new Date() } }, orderBy: { createdAt: "desc" }, select: { id: true, createdAt: true, expiresAt: true, tokenHash: true } });
    return NextResponse.json({ sessions: rows.map(s => ({ id: s.id, createdAt: s.createdAt, expiresAt: s.expiresAt, current: s.tokenHash === sha256(current) })) }, { headers: NO_STORE });
  } catch { return NextResponse.json({ error: "session_list_unavailable" }, { status: 503, headers: NO_STORE }); }
}

/** Revoke one owned session or all sessions except the current device. */
export async function revokeCustomerSessions(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  const customer = await currentCustomer();
  if (!customer) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const body = await req.json().catch(() => null);
  const id = typeof body?.sessionId === "string" ? body.sessionId : "";
  const others = body?.revokeOthers === true;
  if ((!id && !others) || (id && others)) return NextResponse.json({ error: "provide_session_id_or_revoke_others" }, { status: 400, headers: NO_STORE });
  const current = cookies().get(SESSION_COOKIE)?.value || "";
  try {
    const where = others ? { userId: customer.id, revokedAt: null, tokenHash: { not: sha256(current) } } : { id, userId: customer.id, revokedAt: null };
    const result = await prisma.session.updateMany({ where, data: { revokedAt: new Date() } });
    return NextResponse.json({ ok: true, revoked: result.count }, { headers: NO_STORE });
  } catch { return NextResponse.json({ error: "session_revoke_unavailable" }, { status: 503, headers: NO_STORE }); }
}

/** Change password after checking the current password and enrolled MFA. */
export async function changeCustomerPassword(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  const customer = await currentCustomer();
  if (!customer) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const body = await req.json().catch(() => null);
  const currentPassword = typeof body?.currentPassword === "string" ? body.currentPassword : "";
  const newPassword = typeof body?.newPassword === "string" ? body.newPassword : "";
  const mfaCode = typeof body?.mfaCode === "string" ? body.mfaCode : "";
  if (newPassword.length < 12 || newPassword.length > 256 || newPassword === currentPassword) return NextResponse.json({ error: "new_password_must_be_different_and_at_least_12_characters" }, { status: 400, headers: NO_STORE });
  try {
    const user = await prisma.user.findUnique({ where: { id: customer.id }, select: { passwordHash: true, mfaEnrolled: true, mfaSecretEnc: true } });
    if (!user?.passwordHash || !verifyPassword(currentPassword, user.passwordHash)) return NextResponse.json({ error: "current_password_incorrect" }, { status: 403, headers: NO_STORE });
    if (user.mfaEnrolled && (!user.mfaSecretEnc || !verifyTotp(decryptMfaSecret(user.mfaSecretEnc), mfaCode, Math.floor(Date.now() / 1000)))) return NextResponse.json({ error: "valid_authenticator_code_required" }, { status: 403, headers: NO_STORE });
    const current = cookies().get(SESSION_COOKIE)?.value || "";
    await prisma.$transaction(async tx => {
      await tx.user.update({ where: { id: customer.id }, data: { passwordHash: hashPassword(newPassword) } });
      await tx.session.updateMany({ where: { userId: customer.id, revokedAt: null, tokenHash: { not: sha256(current) } }, data: { revokedAt: new Date() } });
    });
    return NextResponse.json({ ok: true, otherSessionsRevoked: true }, { headers: NO_STORE });
  } catch { return NextResponse.json({ error: "password_change_unavailable" }, { status: 503, headers: NO_STORE }); }
}

export async function logoutCustomer(req: Request) {
  const blocked = rejectCrossOrigin(req); if (blocked) return blocked;
  const token = cookies().get(SESSION_COOKIE)?.value;
  if (token) await prisma.session.updateMany({ where: { tokenHash: sha256(token), revokedAt: null }, data: { revokedAt: new Date() } }).catch(() => undefined);
  const response = NextResponse.json({ ok: true }, { headers: NO_STORE });
  response.cookies.set(SESSION_COOKIE, "", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", maxAge: 0 });
  return response;
}

export async function currentCustomer() {
  const token = cookies().get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const session = await prisma.session.findUnique({ where: { tokenHash: sha256(token) }, select: { userId: true, expiresAt: true, revokedAt: true } });
  if (!session || session.revokedAt || session.expiresAt <= new Date()) return null;
  return prisma.$transaction(async tx => {
    await tx.$queryRaw`SELECT set_config('app.user_id', ${session.userId}, true)`;
    const membership = await tx.userCompany.findFirst({ where: { userId: session.userId, company: { slug: COMPANY_SLUG } }, select: { companyId: true, role: true, user: { select: { email: true, isActive: true, emailVerifiedAt: true } } } });
    if (!membership || !membership.user.isActive || !membership.user.emailVerifiedAt || membership.role !== "customer") return null;
    await tx.$queryRaw`SELECT set_config('app.company_id', ${membership.companyId}, true)`;
    return { id: session.userId, email: membership.user.email, company: COMPANY_SLUG, role: "customer" as const };
  });
}
