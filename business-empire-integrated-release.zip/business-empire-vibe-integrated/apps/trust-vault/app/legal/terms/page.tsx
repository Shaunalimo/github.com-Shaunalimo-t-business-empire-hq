const CONTENT = "<main style={{padding:24,whiteSpace:\"pre-wrap\"}}># Terms of service — Trust Vault Bank\n\n> TEMPLATE — must be reviewed by qualified counsel before production use.\n\nThese terms govern use of Trust Vault Bank services. Liability limits, cancellation and refund rights, service levels and dispute resolution are documented here before go-live.\n</main>";

export default function LegalDocument() {
  return <main style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}><pre style={{ whiteSpace: "pre-wrap", fontFamily: "inherit", lineHeight: 1.6 }}>{CONTENT}</pre></main>;
}
