import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Trust Vault Bank",
  description: "Secure customer digital vault and financial services platform.",
  openGraph: { title: "Trust Vault Bank", description: "Secure customer digital vault and financial services platform." },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en-GB"><body>{children}</body></html>);
}
