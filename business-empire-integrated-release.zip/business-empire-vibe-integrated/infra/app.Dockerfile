FROM node:20-alpine
# Prisma's query engine needs OpenSSL on Alpine.
RUN apk add --no-cache openssl
WORKDIR /srv
ARG APP=hq
COPY . .
RUN npm install
# Scripts are not skipped on purpose: the shared Prisma client must be generated before `next build`.
RUN npx prisma generate --schema packages/db/prisma/schema.prisma
WORKDIR /srv/apps/${APP}
RUN npm run build
CMD ["npm", "start"]
