-- Phase 14: Vibe Coding Platform project workspaces and marketplace drafts.
-- All project content remains tenant-isolated. Public marketplace access is
-- limited to listing metadata explicitly marked published.

CREATE TABLE "VibeProject" (
  "id" TEXT NOT NULL,
  "companyId" TEXT NOT NULL,
  "ownerUserId" TEXT NOT NULL,
  "targetBusinessSlug" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "prompt" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'draft',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "VibeProject_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "VibeProject_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "VibeProject_ownerUserId_fkey" FOREIGN KEY ("ownerUserId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "VibeProject_targetBusinessSlug_check" CHECK ("targetBusinessSlug" IN ('growthboost','ai-magazine','trust-vault','stock-express','real-estate','supergpu','dailyaccess')),
  CONSTRAINT "VibeProject_status_check" CHECK ("status" IN ('draft','queued','building','generated','ready','failed'))
);
CREATE INDEX "VibeProject_companyId_updatedAt_idx" ON "VibeProject"("companyId", "updatedAt");
CREATE INDEX "VibeProject_ownerUserId_updatedAt_idx" ON "VibeProject"("ownerUserId", "updatedAt");
CREATE INDEX "VibeProject_targetBusinessSlug_idx" ON "VibeProject"("targetBusinessSlug");

CREATE TABLE "VibeProjectFile" (
  "id" TEXT NOT NULL,
  "projectId" TEXT NOT NULL,
  "path" TEXT NOT NULL,
  "language" TEXT NOT NULL DEFAULT 'text',
  "content" TEXT NOT NULL,
  "version" INTEGER NOT NULL DEFAULT 1,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "VibeProjectFile_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "VibeProjectFile_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "VibeProject"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "VibeProjectFile_projectId_path_key" UNIQUE ("projectId", "path")
);
CREATE INDEX "VibeProjectFile_projectId_idx" ON "VibeProjectFile"("projectId");

CREATE TABLE "VibeProjectRun" (
  "id" TEXT NOT NULL,
  "projectId" TEXT NOT NULL,
  "status" TEXT NOT NULL,
  "provider" TEXT,
  "model" TEXT,
  "errorCode" TEXT,
  "inputTokens" INTEGER,
  "outputTokens" INTEGER,
  "totalTokens" INTEGER,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "startedAt" TIMESTAMP(3),
  "finishedAt" TIMESTAMP(3),
  CONSTRAINT "VibeProjectRun_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "VibeProjectRun_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "VibeProject"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "VibeProjectRun_status_check" CHECK ("status" IN ('queued','running','succeeded','failed'))
);
CREATE INDEX "VibeProjectRun_projectId_createdAt_idx" ON "VibeProjectRun"("projectId", "createdAt");

CREATE TABLE "VibePlanSubscription" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "planCode" TEXT NOT NULL DEFAULT 'free',
  "websiteCount" INTEGER NOT NULL DEFAULT 0,
  "status" TEXT NOT NULL DEFAULT 'active',
  "provider" TEXT,
  "providerRef" TEXT,
  "currentPeriodEnd" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "VibePlanSubscription_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "VibePlanSubscription_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "VibePlanSubscription_userId_key" UNIQUE ("userId"),
  CONSTRAINT "VibePlanSubscription_planCode_check" CHECK ("planCode" IN ('free','starter','pro','business','unlimited')),
  CONSTRAINT "VibePlanSubscription_websiteCount_check" CHECK ("websiteCount" >= 0),
  CONSTRAINT "VibePlanSubscription_status_check" CHECK ("status" IN ('active','past_due','canceled'))
);
CREATE INDEX "VibePlanSubscription_userId_status_idx" ON "VibePlanSubscription"("userId", "status");

CREATE TABLE "VibeMarketplaceListing" (
  "id" TEXT NOT NULL,
  "projectId" TEXT NOT NULL,
  "companyId" TEXT NOT NULL,
  "ownerUserId" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "priceMinor" INTEGER NOT NULL,
  "currency" TEXT NOT NULL DEFAULT 'GBP',
  "status" TEXT NOT NULL DEFAULT 'draft',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "VibeMarketplaceListing_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "VibeMarketplaceListing_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "VibeProject"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "VibeMarketplaceListing_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES "Company"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "VibeMarketplaceListing_ownerUserId_fkey" FOREIGN KEY ("ownerUserId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "VibeMarketplaceListing_projectId_key" UNIQUE ("projectId"),
  CONSTRAINT "VibeMarketplaceListing_priceMinor_check" CHECK ("priceMinor" > 0),
  CONSTRAINT "VibeMarketplaceListing_status_check" CHECK ("status" IN ('draft','pending_review','published','sold','withdrawn'))
);
CREATE INDEX "VibeMarketplaceListing_status_createdAt_idx" ON "VibeMarketplaceListing"("status", "createdAt");
CREATE INDEX "VibeMarketplaceListing_companyId_ownerUserId_idx" ON "VibeMarketplaceListing"("companyId", "ownerUserId");

-- Tenant-owned projects: owners can read/write their own projects. Staff/admin
-- memberships may read tenant projects; writes remain owner-attributed.
ALTER TABLE "VibeProject" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "VibeProject" FORCE ROW LEVEL SECURITY;
CREATE POLICY vibe_project_tenant_select ON "VibeProject" FOR SELECT USING (
  "companyId" = NULLIF(current_setting('app.company_id', true), '') AND (
    "ownerUserId" = NULLIF(current_setting('app.user_id', true), '') OR EXISTS (
      SELECT 1 FROM "UserCompany" m WHERE m."companyId" = "VibeProject"."companyId"
      AND m."userId" = NULLIF(current_setting('app.user_id', true), '')
      AND m."role" IN ('staff','admin','ceo')
    )
  )
);
CREATE POLICY vibe_project_owner_insert ON "VibeProject" FOR INSERT WITH CHECK (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "ownerUserId" = NULLIF(current_setting('app.user_id', true), '')
  AND EXISTS (
    SELECT 1 FROM "Company" c WHERE c."id" = "VibeProject"."companyId" AND (
      (c."slug" = "VibeProject"."targetBusinessSlug" AND EXISTS (
        SELECT 1 FROM "UserCompany" m WHERE m."companyId" = c."id"
          AND m."userId" = NULLIF(current_setting('app.user_id', true), '')
          AND m."role" IN ('customer','staff','admin')
      )) OR (c."slug" = 'hq' AND EXISTS (
        SELECT 1 FROM "UserCompany" m WHERE m."companyId" = c."id"
          AND m."userId" = NULLIF(current_setting('app.user_id', true), '')
          AND m."role" = 'ceo'
      ))
    )
  )
);
CREATE POLICY vibe_project_owner_update ON "VibeProject" FOR UPDATE USING (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "ownerUserId" = NULLIF(current_setting('app.user_id', true), '')
) WITH CHECK (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "ownerUserId" = NULLIF(current_setting('app.user_id', true), '')
  AND EXISTS (
    SELECT 1 FROM "Company" c WHERE c."id" = "VibeProject"."companyId" AND (
      (c."slug" = "VibeProject"."targetBusinessSlug" AND EXISTS (
        SELECT 1 FROM "UserCompany" m WHERE m."companyId" = c."id"
          AND m."userId" = NULLIF(current_setting('app.user_id', true), '')
          AND m."role" IN ('customer','staff','admin')
      )) OR (c."slug" = 'hq' AND EXISTS (
        SELECT 1 FROM "UserCompany" m WHERE m."companyId" = c."id"
          AND m."userId" = NULLIF(current_setting('app.user_id', true), '')
          AND m."role" = 'ceo'
      ))
    )
  )
);

ALTER TABLE "VibeProjectFile" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "VibeProjectFile" FORCE ROW LEVEL SECURITY;
CREATE POLICY vibe_project_file_scope ON "VibeProjectFile" FOR ALL USING (
  EXISTS (SELECT 1 FROM "VibeProject" p WHERE p."id" = "VibeProjectFile"."projectId"
    AND p."companyId" = NULLIF(current_setting('app.company_id', true), '')
    AND (p."ownerUserId" = NULLIF(current_setting('app.user_id', true), '') OR EXISTS (
      SELECT 1 FROM "UserCompany" m WHERE m."companyId" = p."companyId"
      AND m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" IN ('staff','admin','ceo')
    )))
) WITH CHECK (
  EXISTS (SELECT 1 FROM "VibeProject" p WHERE p."id" = "VibeProjectFile"."projectId"
    AND p."companyId" = NULLIF(current_setting('app.company_id', true), '')
    AND p."ownerUserId" = NULLIF(current_setting('app.user_id', true), ''))
);

ALTER TABLE "VibeProjectRun" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "VibeProjectRun" FORCE ROW LEVEL SECURITY;
CREATE POLICY vibe_project_run_scope ON "VibeProjectRun" FOR ALL USING (
  EXISTS (SELECT 1 FROM "VibeProject" p WHERE p."id" = "VibeProjectRun"."projectId"
    AND p."companyId" = NULLIF(current_setting('app.company_id', true), '')
    AND (p."ownerUserId" = NULLIF(current_setting('app.user_id', true), '') OR EXISTS (
      SELECT 1 FROM "UserCompany" m WHERE m."companyId" = p."companyId"
      AND m."userId" = NULLIF(current_setting('app.user_id', true), '') AND m."role" IN ('staff','admin','ceo')
    )))
) WITH CHECK (
  EXISTS (SELECT 1 FROM "VibeProject" p WHERE p."id" = "VibeProjectRun"."projectId"
    AND p."companyId" = NULLIF(current_setting('app.company_id', true), '')
    AND p."ownerUserId" = NULLIF(current_setting('app.user_id', true), ''))
);

ALTER TABLE "VibePlanSubscription" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "VibePlanSubscription" FORCE ROW LEVEL SECURITY;
CREATE POLICY vibe_plan_owner_scope ON "VibePlanSubscription" FOR ALL USING (
  "userId" = NULLIF(current_setting('app.user_id', true), '')
) WITH CHECK (
  "userId" = NULLIF(current_setting('app.user_id', true), '')
);

-- Public marketplace visitors can read only explicitly published listing
-- metadata. Drafts and review records remain visible only to their owner.
ALTER TABLE "VibeMarketplaceListing" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "VibeMarketplaceListing" FORCE ROW LEVEL SECURITY;
CREATE POLICY vibe_marketplace_public_or_owner_read ON "VibeMarketplaceListing" FOR SELECT USING (
  "status" = 'published' OR (
    "companyId" = NULLIF(current_setting('app.company_id', true), '')
    AND "ownerUserId" = NULLIF(current_setting('app.user_id', true), '')
  )
);
CREATE POLICY vibe_marketplace_owner_insert ON "VibeMarketplaceListing" FOR INSERT WITH CHECK (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "ownerUserId" = NULLIF(current_setting('app.user_id', true), '')
  AND "status" = 'draft'
  AND EXISTS (SELECT 1 FROM "VibeProject" p WHERE p."id" = "VibeMarketplaceListing"."projectId"
    AND p."companyId" = "VibeMarketplaceListing"."companyId"
    AND p."ownerUserId" = NULLIF(current_setting('app.user_id', true), ''))
);
CREATE POLICY vibe_marketplace_owner_update ON "VibeMarketplaceListing" FOR UPDATE USING (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "ownerUserId" = NULLIF(current_setting('app.user_id', true), '')
) WITH CHECK (
  "companyId" = NULLIF(current_setting('app.company_id', true), '')
  AND "ownerUserId" = NULLIF(current_setting('app.user_id', true), '')
  AND "status" IN ('draft','withdrawn')
  AND EXISTS (SELECT 1 FROM "VibeProject" p WHERE p."id" = "VibeMarketplaceListing"."projectId"
    AND p."companyId" = "VibeMarketplaceListing"."companyId"
    AND p."ownerUserId" = NULLIF(current_setting('app.user_id', true), ''))
);
