-- Phase 8: allow an authenticated user to resolve only companies where they
-- hold a membership before app.company_id is known. UserCompany's own RLS
-- policy is keyed by app.user_id, so this does not expose the company directory.
-- Run as the migration/admin role. Runtime role must not own tables or bypass RLS.
ALTER TABLE "Company" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Company" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS company_tenant_isolation ON "Company";
CREATE POLICY company_tenant_isolation ON "Company"
  USING (
    "id" = NULLIF(current_setting('app.company_id', true), '')
    OR EXISTS (
      SELECT 1 FROM "UserCompany" membership
      WHERE membership."companyId" = "Company"."id"
        AND membership."userId" = NULLIF(current_setting('app.user_id', true), '')
    )
  )
  WITH CHECK (
    "id" = NULLIF(current_setting('app.company_id', true), '')
  );

-- Explicitly document the required runtime assumptions for the API wrapper.
-- app.user_id is set only after a server-side session is verified; app.company_id
-- is set only after a matching UserCompany row is found for the fixed app slug.

-- Memberships are identity-managed. Runtime tenant roles may read their own
-- memberships to resolve access, but cannot self-enrol, self-promote or delete
-- membership records. Provisioning is handled by the controlled identity flow.
DROP POLICY IF EXISTS user_membership_isolation ON "UserCompany";
DROP POLICY IF EXISTS user_membership_read_self ON "UserCompany";
CREATE POLICY user_membership_read_self ON "UserCompany"
  FOR SELECT
  USING ("userId" = NULLIF(current_setting('app.user_id', true), ''));

-- Audit events are append-only for application roles. No UPDATE or DELETE
-- policy is created, so a tenant app cannot rewrite or erase its audit trail.
DROP POLICY IF EXISTS tenant_isolation ON "AuditLog";
DROP POLICY IF EXISTS tenant_audit_read ON "AuditLog";
DROP POLICY IF EXISTS tenant_audit_insert ON "AuditLog";
CREATE POLICY tenant_audit_read ON "AuditLog"
  FOR SELECT
  USING ("companyId" IS NOT NULL AND "companyId" = NULLIF(current_setting('app.company_id', true), ''));
CREATE POLICY tenant_audit_insert ON "AuditLog"
  FOR INSERT
  WITH CHECK ("companyId" IS NOT NULL AND "companyId" = NULLIF(current_setting('app.company_id', true), ''));

-- Recovery codes are user-owned secrets. They can be selected/consumed only
-- while the authenticated user's ID is set in the transaction context.
ALTER TABLE "RecoveryCode" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "RecoveryCode" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS recovery_code_user_scope ON "RecoveryCode";
CREATE POLICY recovery_code_user_scope ON "RecoveryCode"
  USING ("userId" = NULLIF(current_setting('app.user_id', true), ''))
  WITH CHECK ("userId" = NULLIF(current_setting('app.user_id', true), ''));

-- Intercompany authorisations are immutable application records: participant
-- companies may read; only the originating company may insert. No update/delete
-- policy is provided for runtime roles.
DROP POLICY IF EXISTS intercompany_participant_isolation ON "IntercompanyAuthorisation";
DROP POLICY IF EXISTS intercompany_participant_read ON "IntercompanyAuthorisation";
DROP POLICY IF EXISTS intercompany_origin_insert ON "IntercompanyAuthorisation";
CREATE POLICY intercompany_participant_read ON "IntercompanyAuthorisation"
  FOR SELECT
  USING (
    "fromCompanyId" = NULLIF(current_setting('app.company_id', true), '') OR
    "toCompanyId" = NULLIF(current_setting('app.company_id', true), '')
  );
CREATE POLICY intercompany_origin_insert ON "IntercompanyAuthorisation"
  FOR INSERT
  WITH CHECK ("fromCompanyId" = NULLIF(current_setting('app.company_id', true), ''));
