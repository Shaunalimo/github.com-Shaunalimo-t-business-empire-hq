/** Shared, provider-independent rules for the Vibe Coding Platform. */
export const VIBE_BUSINESS_TARGETS = [
  "growthboost",
  "ai-magazine",
  "trust-vault",
  "stock-express",
  "real-estate",
  "supergpu",
  "dailyaccess",
] as const;

export type VibeBusinessSlug = (typeof VIBE_BUSINESS_TARGETS)[number];
export type VibePlanCode = "free" | "starter" | "pro" | "business" | "unlimited";

/** Paid limits are proposed configuration values, not active billing entitlements. */
export const VIBE_PLAN_LIMITS: Record<VibePlanCode, number | null> = {
  free: 3,
  starter: 10,
  pro: 25,
  business: 100,
  unlimited: null,
};

export function isVibeBusinessSlug(value: unknown): value is VibeBusinessSlug {
  return typeof value === "string" && (VIBE_BUSINESS_TARGETS as readonly string[]).includes(value);
}

export function isVibePlanCode(value: unknown): value is VibePlanCode {
  return typeof value === "string" && Object.prototype.hasOwnProperty.call(VIBE_PLAN_LIMITS, value);
}

export function canCreateVibeProject(plan: unknown, projectCount: number): boolean {
  const code: VibePlanCode = isVibePlanCode(plan) ? plan : "free";
  const limit = VIBE_PLAN_LIMITS[code];
  return limit === null || (Number.isInteger(projectCount) && projectCount >= 0 && projectCount < limit);
}

export function isSafeVibeProjectPath(value: unknown): value is string {
  if (typeof value !== "string" || value.length < 1 || value.length > 160) return false;
  if (value.startsWith("/") || value.includes("\\") || value.includes("\0")) return false;
  const segments = value.split("/");
  return segments.every((part) => part.length > 0 && part !== "." && part !== "..") &&
    /^[A-Za-z0-9._/-]+$/.test(value);
}

export function escapeVibeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[character] ?? character);
}
