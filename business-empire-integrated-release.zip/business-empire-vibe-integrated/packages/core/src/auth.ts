import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import type { AuthContext, Permission } from "./rbac";
import { can, requirePermission } from "./rbac";

/**
 * Password hashing with scrypt. In production this module is replaced by the
 * managed auth service (Cognito/Auth0) — this implementation exists so the
 * platform and its tests are fully runnable without external dependencies.
 */
export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, 64);
  return `scrypt$${salt.toString("hex")}$${hash.toString("hex")}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [scheme, saltHex, hashHex] = stored.split("$");
  if (scheme !== "scrypt" || !saltHex || !hashHex) return false;
  const hash = scryptSync(password, Buffer.from(saltHex, "hex"), 64);
  const expected = Buffer.from(hashHex, "hex");
  return hash.length === expected.length && timingSafeEqual(hash, expected);
}

export function newSessionToken(): string {
  return randomBytes(32).toString("base64url");
}

export function sha256(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}

/**
 * Example secure route handler wrapper: authentication is assumed handled by
 * the managed auth service producing an AuthContext; authorisation is
 * enforced per company with the shared RBAC module.
 */
export interface ApiRequest {
  auth?: AuthContext;
  companyId: string;
}

export function authorize(
  req: ApiRequest,
  permission: Permission,
): { ok: true } | { ok: false; status: 401 | 403; error: string } {
  if (!req.auth) return { ok: false, status: 401, error: "authentication required" };
  try {
    requirePermission(req.auth, req.companyId, permission);
    return { ok: true };
  } catch {
    return { ok: false, status: 403, error: `forbidden: ${permission}` };
  }
}

export { can } from "./rbac";
