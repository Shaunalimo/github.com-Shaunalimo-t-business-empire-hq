import type { Currency } from "./entities";

/**
 * Money is stored and transferred as integer minor units (pence for GBP).
 * Floating point is never used for arithmetic on amounts.
 */

export interface Money {
  currency: Currency;
  /** Amount in minor units (pence). May be negative for balancing entries. */
  minor: number;
}

export function gbp(pounds: number, pence = 0): Money {
  if (!Number.isInteger(pounds) || !Number.isInteger(pence)) {
    throw new Error("money must be constructed from integer pounds/pence");
  }
  return { currency: "GBP", minor: pounds * 100 + pence };
}

export function money(currency: Currency, minor: number): Money {
  if (!Number.isInteger(minor)) throw new Error("minor units must be an integer");
  return { currency, minor };
}

export function add(a: Money, b: Money): Money {
  assertSameCurrency(a, b);
  return { currency: a.currency, minor: a.minor + b.minor };
}

export function sum(amounts: Money[]): Money {
  if (amounts.length === 0) return { currency: "GBP", minor: 0 };
  return amounts.reduce((acc, m) => add(acc, m));
}

export function format(m: Money): string {
  const sign = m.minor < 0 ? "-" : "";
  const abs = Math.abs(m.minor);
  const pounds = Math.floor(abs / 100);
  const pence = abs % 100;
  return `${sign}£${pounds.toLocaleString("en-GB")}.${pence.toString().padStart(2, "0")}`;
}

export function assertSameCurrency(a: Money, b: Money): void {
  if (a.currency !== b.currency) {
    throw new Error(`currency mismatch: ${a.currency} vs ${b.currency}`);
  }
}

/** Multi-currency amounts are never mixed silently — this is the only path. */
export function convertToReportingCurrency(
  m: Money,
  rateToGBP: number,
): { value: Money; rateUsed: number } {
  if (m.currency === "GBP") return { value: m, rateUsed: 1 };
  if (!(rateToGBP > 0) || !Number.isFinite(rateToGBP)) {
    throw new Error("a finite positive FX rate is required for non-GBP amounts");
  }
  return { value: { currency: "GBP", minor: Math.round(m.minor * rateToGBP) }, rateUsed: rateToGBP };
}
