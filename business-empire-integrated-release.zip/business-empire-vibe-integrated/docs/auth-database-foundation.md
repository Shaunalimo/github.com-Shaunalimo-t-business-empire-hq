# CEO authentication and database foundation

This phase adds database-backed CEO login, password verification using the shared scrypt helper, mandatory TOTP MFA for CEO accounts, hashed opaque session tokens, eight-hour HTTP-only SameSite=Strict cookies, logout/revocation, session inspection, and a successful-login audit event. Consolidated reporting requires a verified CEO session and remains fail-closed until the ledger is connected.

## Provisioning and deployment
1. Configure PostgreSQL `DATABASE_URL` and `DIRECT_URL`.
2. Install dependencies, generate Prisma client, validate schema and apply migrations.
3. Set `AUTH_MFA_ENCRYPTION_KEY` to a base64-encoded 32-byte key (`openssl rand -base64 32`) in a secret manager.
4. Create the HQ company row (`slug=hq`) and provision the owner User row with a scrypt password hash, encrypted TOTP secret in `mfaSecretEnc`, `mfaEnrolled=true`, and UserCompany membership role `ceo`. Do not expose public CEO registration.
5. Deploy behind HTTPS and a trusted reverse proxy. Add proxy-level login rate limiting, request-size limits, security headers, monitoring, backups and alerting. Ensure forwarded IP headers are overwritten by the trusted proxy.

## API
- `POST /api/auth/login` JSON `{ "email": "...", "password": "...", "code": "123456" }`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/consolidated` (CEO session required; returns 503 until ledger integration)

## Boundaries
No CEO account, secret, database or MFA device is created by this source patch. The application still requires dependency installation, Prisma migration, secure owner provisioning, login rate limiting, CSRF/origin controls on state-changing routes, recovery workflow, session cleanup, security review and PostgreSQL integration tests before production. Customer banking data is not exposed through cross-company reporting.
