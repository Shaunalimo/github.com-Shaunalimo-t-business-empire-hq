# Integration Register

Status meaning — **connected**: live and verified · **pending**: contracted or
planned, not yet verified · **unavailable**: no authorised path exists yet.

| # | Service | Company | Kind | Status | Notes |
|---|---|---|---|---|---|
| 1 | PostgreSQL | All | Data | **pending** | Managed instance provisioned at deploy; schema + RLS ready |
| 2 | Managed auth (MFA/TOTP) | All | Auth | **pending** | TOTP implementation shipped in core; IdP wiring at deploy |
| 3 | Object storage (S3+KMS) | All | Storage | **pending** | Bucket + versioning at deploy |
| 4 | Stripe (or equivalent PSP) | All seven | Payment | **unavailable** | Needs merchant account per company; UI shows “payments unavailable” until connected |
| 5 | Email (SMTP/SES) | All | Notifications | **pending** | Templates ready |
| 6 | Sentry + OpenTelemetry | All | Observability | **pending** | DSNs at deploy |
| 7 | Market data feed | Stock Market Express | Data | **unavailable** | Requires licensed data provider |
| 8 | Brokerage / order routing | Stock Market Express | Trading | **unavailable** | Requires appropriately authorised partner; **paper trading only** meanwhile |
| 9 | Banking / e-money partner | Trust Vault Bank | Financial services | **unavailable** | Requires appropriately authorised partner; no banking data stored until signed |
| 10 | Analytics (privacy-preserving) | All | Analytics | **pending** | Plausible/self-hosted recommended |
| 11 | Domain + DNS + TLS | All | Hosting | **pending** | Per-company subdomains |
| 12 | AI briefing assistant (HQ) | HQ | AI | **connected (local)** | Uses consolidated data only; no external AI provider wired yet |
| 13 | Vibe Coding Platform project storage | All seven + HQ | Data | **pending** | Phase 14 schema, project APIs and RLS source added; migrations and runtime isolation tests still required |
| 14 | AI model gateway | Vibe Coding Platform | AI | **pending** | Generation endpoint uses the Vercel AI Gateway-compatible Chat Completions API when `AI_GATEWAY_API_KEY` and `VIBE_AI_MODEL` are configured; runtime verification and budgets remain outstanding |
| 15 | Isolated code sandbox | Vibe Coding Platform | Hosting | **unavailable** | No remote code execution, dependency installation or hosted preview until a sandbox provider is integrated and tested |
| 16 | Website domain + deployment provider | Vibe Coding Platform | Hosting | **unavailable** | Local sandboxed HTML preview only; custom domains, public deployment and DNS/TLS automation are not connected |
| 17 | Website marketplace payments | Vibe Coding Platform | Payment | **unavailable** | Draft listings only; moderation, checkout, ownership transfer, refunds, disputes and seller payouts require a verified PSP integration |

Review cadence: monthly, owned by the CEO office; changes are audit-logged.
