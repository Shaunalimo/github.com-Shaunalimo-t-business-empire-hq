# Phase 11 — customer account security

## Implemented in source

- Customer email verification requests and one-time confirmation tokens. Only token hashes are stored; tokens expire after 30 minutes and are consumed once.
- Email delivery is delegated to a server-side webhook configured with `AUTH_EMAIL_WEBHOOK_URL`, `AUTH_EMAIL_WEBHOOK_SECRET`, and `PUBLIC_APP_URL`. No verification token is returned to the browser. The public request response is generic to reduce account enumeration.
- Customer login now requires a verified email address.
- Customer MFA enrolment uses TOTP. The secret is encrypted at rest using the existing AES-256-GCM key (`AUTH_MFA_ENCRYPTION_KEY`), and enrolment is enabled only after a valid authenticator code is confirmed.
- Existing MFA must be proven before replacing an enrolled authenticator secret.
- Customer login enforces TOTP when enrolled; alternatively, a single-use recovery code may be used.
- Ten recovery codes can be generated after TOTP confirmation. Only SHA-256 hashes are stored; plaintext is returned once.
- Customer registration, login and verification requests use the existing shared database-backed authentication throttle.
- The same customer security routes are included in all seven business apps. CEO HQ authentication remains separate.

## Endpoints per business app

- `POST /api/auth/email/verification/request` — generic verification request; email delivery requires the configured webhook.
- `POST /api/auth/email/verification/confirm` — consume a verification token.
- `POST /api/auth/mfa/start` — authenticated TOTP setup; when replacing existing MFA, `currentCode` is required.
- `POST /api/auth/mfa/confirm` — confirm setup with `{ "code": "123456" }`.
- `POST /api/auth/recovery-codes` — rotate recovery codes with `{ "code": "123456" }`.
- `POST /api/auth/login` — when MFA is enabled, accepts `mfaCode` or `recoveryCode` in addition to email/password.

## Required configuration

Set the following server-side only:

- `AUTH_MFA_ENCRYPTION_KEY` — base64 encoding of a cryptographically random 32-byte key. Keep it in a secret manager and back it up securely; losing it prevents decrypting enrolled authenticator secrets.
- `AUTH_EMAIL_WEBHOOK_URL` — trusted HTTPS endpoint for a transactional email adapter.
- `AUTH_EMAIL_WEBHOOK_SECRET` — bearer secret for that adapter.
- `PUBLIC_APP_URL` — canonical HTTPS origin used to construct verification links.

The webhook contract is a server-to-server POST JSON body containing `to`, `subject`, `text`, and `application`. The receiving adapter must authenticate the bearer secret, validate recipient and content, prevent open-relay behaviour, log delivery status without logging tokens, and send through a reputable transactional email provider.

## Limitations and launch gates

- Email delivery is not live until a real provider adapter is configured and tested. The project does not claim that messages are being sent.
- Password-reset email and password-reset token workflow are not included in this phase.
- Rate limiting uses the existing `AuthThrottle` table and proxy-provided `x-real-ip`; deployment must configure a trusted reverse proxy that overwrites this header. The current upsert strategy is a baseline and requires concurrency/load testing.
- TOTP/recovery endpoints require the database migration and key configuration. MFA should be tested on staging before being required for customers.
- The Phase 11 migration has not been applied to a live database. Prisma generation, full TypeScript checks, automated suite, production builds, penetration testing and deployment remain outstanding.
- Public registration remains disabled by default. Do not enable it until the mail adapter, migration, consent/terms workflow, account recovery, abuse controls, monitoring and independent security review are complete.
- Trust Vault login does not grant banking/e-money permissions or replace KYC/AML and FCA/PRA authorisation or an authorised partner.
